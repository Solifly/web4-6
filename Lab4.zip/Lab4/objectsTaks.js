// 2.3.1
//Створення звичайного об’єкту гравця з властивостями нікнейму і рейтингу
let player = {
   nickName: "Solify",
   rating: 12
}

// 2.3.2
// Створення об'єкту з властивостями
let cyberSportPlayer = {
   teamNickName: "Navi",
   teamRole: "Sniper",
   // 2.3.2
   getTeamNickName: () => {
      return this.teamNickName;
   },
   setTeamNickName: (teamNickName) => {
      this.teamNickName = teamNickName;
   },
   getTeamRole: () => {
      return this.teamRole;
   },
   setTeamRole: (teamRole) => {
      this.teamRole = teamRole;
   }
}

// 2.3.4
// Додавання в прототип об’єкту cyberSportPlayer метод для виводу даних
cyberSportPlayer.getStat = () => {
   return `${cyberSportPlayer.getTeamNickName()}, ${cyberSportPlayer.getTeamRole()}`;
}

// 2.3.5
// Створення об’єкту career, що наслідує властивості і методи об’єкту cyberSportPlayer і має додаткові властивості 
let career = {
   bestMatch: "2015 Navi vs. G2",
   wins: 3,
   countOfGames: 54,
   winRate: () => {
      return wins/countOfGames;
   },
   __proto__: cyberSportPlayer
};

// Перевизначення роботи методу getStat
career.getStat = () => {
   return `${career.getTeamNickName()}, ${career.getTeamRole()}, ${career.bestMatch}, ${career.wins}, ${career.countOfGames}`;
}

// 2.3.1
// Створення класу гравця
class Player {
   constructor(nickName,rating) {
      this.nickName = nickName;
      this.rating = rating;
   }

   getNickName() {
      return this.nickName; 
   }
   
   getSurNickName() {
      return this.rating; 
   }

   setNickName(nickName) {
      this.nickName = nickName;
   }
   
   setSurNickName(nickName) {
      this.nickName = nickName;
   }
}

// 2.3.2
// Створення класу CyberSportPlayer
class CyberSportPlayer {
   constructor(teamNickName, teamRole) {
      this.teamNickName = teamNickName;
      this.teamRole = teamRole;
   }

   getTeamNickName() {
      return this.teamNickName;
   }

   setTeamNickName(teamNickName) {
      this.teamNickName = teamNickName;
   }

   getTeamRole() {
      return this.teamRole;
   }

   setTeamRole(teamRole) {
      this.teamRole = teamRole;
   }
}

// 2.3.4
// Додавання в прототип об’єкту CyberSportPlayer метод для виведення даних
CyberSportPlayer.prototype.getStat = () => {
   return `\\${this.teamNickName }, ${this.teamRole }`
}

// 2.3.5
// Створення об’єкту career, що наслідує властивості і методи об’єкту cyberSportPlayer і має додаткові властивості
class Career extends CyberSportPlayer {
   
   constructor(teamNickName, teamRole,bestMatch,wins,countOfGames) {
      super(teamNickName,teamRole);
      this.bestMatch = bestMatch; 
      this.wins = wins; 
      this.countOfGames = countOfGames; 
   }

   setBestMatch (bestMatch) {
      this.bestMatch = bestMatch; 
   } 

   setWins(wins) { 
      this.wins = wins; 
   } 
   
   setCountOfGames (countOfGames) { 
      this.countOfGames = countOfGames; 
   } 
   
   getBestMatch() { 
      return this.bestMatch;
   } 
   
   getWins () { 
      return this.wins; 
   } 
   
   getCountOfGames () { 
      return this.countOfGames; 
   } 

   winRate () {
      return this.winRate/this.countOfGames;
   }

   // Перезапис методу виводу інформації про об'єкт класу 
   getStat = function() {
      return `nickName: ${this.nickName } rating: ${this.rating } GROUP: ${this.teamNickName } SPECIAL: ${this.teamRole }`
   }
}