var TOKEN = "1858844290:AAG4xVcUFcD6nNnKqz1biKvcGrhwNCsOHMk";
var CHAT_ID = "-519873227";

const testContent = [
    {
        t: "Radio",
		q: "Що таке canvas в html5?",
		a: ['1. Це спеціальне поле для створення адаптиву.',
        '2. Це спеціальне поле для створення виключно діаграм і графіків',
        '3. Це спеціальне поле для малювання у браузері на JavaScript.',
        '4. Це спеціальне поле для малювання виключно таблиць.'],
		correctAnswer: '3. Це спеціальне поле для малювання у браузері на JavaScript.',
        img: "./images/test1.png"
	},
    {
        t: "Select",
		q: "Як оголосити сanvas в html5?",
		a: ['1. <canvas id="canvas" width="200" height="200"></canvas> ',
        '2. <canv id="canvas" width="200" height="200"></canv>',
        '3. <canvac id="canvac" width="200" height="200"></canvac>',
        '4. <c> id="canvas" width="200" height="200"></c>'],
		correctAnswer: '1. <canvas id="canvas" width="200" height="200"></canvas>',
	},
    {
        t: "Radio",
		q: "Як оголосити змінну canvas в JS?",
		a: ["1. var canvas = document.getElementById('canvas');",
        "2. var canvas = getElementById('canvas');",
        "3. canvas = document.getElementById('canvas');",
        "4. var canvas = document.getElement('canvas');"],
		correctAnswer: "1. var canvas = document.getElementById('canvas');",
        img: "./images/test1.png"
	},
    {
        t: "Select",
		q: "Як отримати контекст canvas?",
		a: ["1. ctx = canvas.getContext('2d');",
        "2. var ctx = canvas.getContext('2d');",
        "3. var ctx = getContext('2d');",
        "4. var ctx = canvas.getContext();"],
		correctAnswer: "2. var ctx = canvas.getContext('2d');",
        img: "./images/test1.png"
	},
    {
        t: "CheckBox",
		q: "Різниця між методами moveTo() та lineTo()?",
		a: ["1. Метод lineTo малює від стартової точки до вказаної.",
        "2. Ніякої різниці",
        "3. Метод moveTo малює до стартової точки від вказаної.",
        "4. Метод moveTo встановлює стартову точку."],
		correctAnswer: ['1. Метод lineTo малює від стартової точки до вказаної.',
        '4. Метод moveTo встановлює стартову точку.'] 
	},
    {
        t: "CheckBox",
		q: "Як намалювати прямокутник використовуючи JS?",
		a: ["1. ctx.strokeRect(20, 20, 150, 100); ",
        "2. ctx.fillRect(20, 20, 150, 100);",
        "3. fill.strokeRect(20, 20, 150, 100);",
        "4. ctx.rect(20, 20, 150, 100); ctx.stroke();"],
		correctAnswer: ['1. ctx.strokeRect(20, 20, 150, 100);',
        '2. ctx.fillRect(20, 20, 150, 100);',
        '4. ctx.rect(20, 20, 150, 100); ctx.stroke();'] 
	},
    {
        t: "CheckBox",
		q: "Виберіть правильні твердження.",
		a: ["1. arc() використовує лише координати і радіус",
        "2. arc() використовує лише координати, кути і радіус",
        "3. arcTo() використовує лише координати і радіус",
        "4. arcTo() використовує лише координати, кути і радіус"],
		correctAnswer: ['2. arc() використовує лише координати, кути і радіус',
        '3. arcTo() використовує лише координати і радіус'] 
	},
    {
        t: "Radio",
		q: "Як зробити елемент канвасу клікабельним?",
		a: ["1. document.getElementById('canvasId').EventListener('click',function(evt){\nalert(evt.clientX + ',' + evt.clientY);\n},false);",
        "2. document.getElementById('canvasId').addEventListener('click',function(evt){\nalert(evt.clientX + ',' + evt.clientY);\n},false);",
        "3. document.getElementById('canvasId').addCanvasListener('click',function(evt){\nalert(evt.clientX + ',' + evt.clientY);\n},false);",
        "4. document.getElementById('canvasId').addEventListener('click',function(evt){\nalert(evt.clientX + ',' + evt.clientY);\n});"],
		correctAnswer: "2. document.getElementById('canvasId').addEventListener('click',function(evt){\nalert(evt.clientX + ',' + evt.clientY);\n},false);",
	},
    {
        t: "CheckBox",
		q: "Вкажіть властивості методу lineCap().",
		a: ["1. butt",
        "2. round",
        "3. square",
        "4. line"],
		correctAnswer: ["1. butt",
        "2. round",
        "3. square"] 
	},
    {
        t: "DragAndDrop",
        text: "В якій послідовності потрібно написати ці методи щоб намалювати лінію починаючи з точки (40, 40) до точки (90, 90)?",   
		q: ['1','2','3'],
		a: ['ctx.lineTo(90, 90)','ctx.stroke()','ctx.moveTo(40, 40)'],
		correctAnswer: ['1 - ctx.moveTo(40, 40)','2 - ctx.lineTo(90, 90)','3 - ctx.stroke()']
	}
];

var testNumber = 0;
var mark = 0;
var selected;

const startBTN = document.getElementById("start-button");
const loginWrap = document.getElementById("login-block");

var nameInput;
var groupInput;

startBTN.addEventListener('click', () => {
    nameInput = document.getElementById("Name");
    groupInput = document.getElementById("Group");

    if(nameInput.value === "") alert("Перед початком тесту введіть своє ім'я");
    else if(groupInput.value === "") alert("Перед початком тесту номер своєї групи");
    else {
        loginWrap.classList.add("hide");
    }
});

const cards = document.querySelectorAll('.draganddrop-elem');
const cells = document.querySelectorAll('.cell-field');
var selectedCard;

cells.forEach(cell => {
    cell.addEventListener('dragover', (evt) => {
        evt.preventDefault();
    });
    cell.addEventListener('dragenter', ((evt) => {
        evt.preventDefault();
    }));
    cell.addEventListener('dragleave', (() => {
        cell.classList.remove('hovered');
    }));
    cell.addEventListener('drop', (() => {
        if(!cell.querySelector(".draganddrop-elem")) {
            cell.append(selectedCard);
        } else {
            cell.style.animation = "shake 0.5s ease";
            setTimeout(() => { cell.style.animation = 'none'; }, 500);
        }
    }));
});

cards.forEach(card => {
    card.addEventListener('dragstart', (() => {
        setTimeout(() => {
            card.classList.add('hide');
            selectedCard = card;
        }, 0);
    }));
    card.addEventListener('dragend', (() => {
        card.classList.remove('hide');
    }));
});

const main = document.querySelector(".main");

const CreateTest = () => {
    if(main.querySelector(".removable")) {
        main.removeChild(main.querySelector(".removable"));
    }
    var currentTest = testContent[testNumber];
    switch(currentTest.t) {
        case "Radio": {
            selected = null;
            var template = document.getElementById("radio-test");
            var newTest = template.cloneNode(true);

            newTest.querySelector(".test-text").textContent = currentTest.q;

            if(currentTest.img) {
                var img = newTest.querySelector(".test-image");
                img.querySelector("img").setAttribute("src",currentTest.img);;
                img.classList.remove("hide");
            }
            
            var answerTemplate = newTest.querySelector(".test-fields");
            
            for (let i = 0; i < currentTest.a.length; i++) {
                const answer = currentTest.a[i];
                var newAnswer = answerTemplate.querySelector(".test-field").cloneNode(true);
                var input = newAnswer.querySelector("input");
                input.value = answer;
                input.setAttribute("id","radio" + i);
                newAnswer.querySelector("label").setAttribute("for","radio" + i);
                newAnswer.querySelector("label").textContent = answer;
                newAnswer.classList.remove("hide");
                answerTemplate.appendChild(newAnswer);
            }
            answerTemplate.querySelectorAll("input").forEach(input => {
                input.onclick = (() => {
                    selected = input.value;
                });
            });

            newTest.classList.remove("hide");
            newTest.classList.add("removable");

            newTest.querySelector(".next-button-block").querySelector("input").addEventListener('click', () => {
                if(selected == null) {
                    alert("Ви не обрали жодної відповіді на запитання");
                    return;
                }
                testNumber++;
                if(selected === currentTest.correctAnswer) {
                    mark++;
                }
                if(testNumber < testContent.length) {
                    CreateTest();
                } else {
                    FinishTest();
                }
            });
            main.appendChild(newTest);
            break;
        } 
        case "CheckBox": {
            selected = [];
            var template = document.getElementById("checkbox-test");
            var newTest = template.cloneNode(true);

            newTest.querySelector(".test-text").textContent = currentTest.q;

            if(currentTest.img) {
                var img = newTest.querySelector(".test-image");
                img.querySelector("img").setAttribute("src",currentTest.img);;
                img.classList.remove("hide");
            }

            var answerTemplate = newTest.querySelector(".test-fields");
            for (let i = 0; i < currentTest.a.length; i++) {
                const answer = currentTest.a[i];
                var newAnswer = answerTemplate.querySelector(".test-field").cloneNode(true);
                var input = newAnswer.querySelector("input");
                input.value = answer;
                input.setAttribute("id","checkbox" + i);
                newAnswer.querySelector("label").setAttribute("for","checkbox" + i);
                newAnswer.querySelector("label").textContent = answer;
                newAnswer.classList.remove("hide");
                answerTemplate.appendChild(newAnswer);
            }
            
            answerTemplate.querySelectorAll("input").forEach(input => {
                input.onclick = (() => {
                    if(input.classList.contains("selected")) {
                        input.classList.remove("selected");
                    } else {
                        input.classList.add("selected");
                    }
                });
            });

            newTest.classList.remove("hide");
            newTest.classList.add("removable");

            newTest.querySelector(".next-button-block").querySelector("input").addEventListener('click', () => {
                selected = newTest.querySelectorAll(".selected");
                if(selected.length == 0) {
                    alert("Ви не обрали жодної відповіді на запитання");
                    return;
                }
                testNumber++;
                var qMark = 0;
                selected.forEach(element => {
                    if(currentTest.correctAnswer.includes(element.value)) {
                        qMark+=1/currentTest.correctAnswer.length;
                    } else {
                        qMark-=1/currentTest.correctAnswer.length;
                    }
                });
                if(qMark > 0) mark += qMark;
                if(testNumber < testContent.length) {
                    CreateTest();
                } else {
                    FinishTest();
                }
            });
            main.appendChild(newTest);

            break;
        }
        case "Select": {
            var template = document.getElementById("select-test");
            var newTest = template.cloneNode(true);

            newTest.querySelector(".test-text").textContent = currentTest.q;

            if(currentTest.img) {
                var img = newTest.querySelector(".test-image");
                img.querySelector("img").setAttribute("src",currentTest.img);;
                img.classList.remove("hide");
            }

            var selectPool = newTest.querySelector("select");
            for (let i = 0; i < currentTest.a.length; i++) {
                const answer = currentTest.a[i];
                var newAnswer = document.createElement("option");
                newAnswer.textContent = answer;
                newAnswer.value = answer;
                selectPool.appendChild(newAnswer);
            }

            newTest.classList.remove("hide");
            newTest.classList.add("removable");

            newTest.querySelector(".next-button-block").querySelector("input").addEventListener('click', () => {
                testNumber++;
                selected = selectPool.value;
                if(selected === currentTest.correctAnswer) {
                    mark++;
                }
                if(testNumber < testContent.length) {
                    CreateTest();
                } else {
                    FinishTest();
                }
            });
            main.appendChild(newTest);

            break;
        }
        case "DragAndDrop": {
            selected = [];
            var template = document.getElementById("draganddrop-test");
            var newTest = template.cloneNode(true);

            newTest.querySelector(".test-text").textContent = currentTest.text;

            var answersPool = newTest.querySelector(".answers-elems");
            var answerTemplate = newTest.querySelector(".answers-elems").querySelector(".test-field");

            currentTest.a.forEach(answer => {
                var newAnswer = answerTemplate.cloneNode(true);
                newAnswer.classList.remove("hide");
                newAnswer.querySelector("input").value = answer;
                answersPool.appendChild(newAnswer);
            });

            var questionPool = newTest.querySelector(".questions-elems");
            var questionTemplate = questionPool.querySelector(".cell-field");
            currentTest.q.forEach(question => {
                var newQuestion = questionTemplate.cloneNode(true);
                newQuestion.classList.remove("hide");
                newQuestion.querySelector(".cell-bg").textContent = question;
                questionPool.appendChild(newQuestion);
            });

            newTest.classList.remove("hide");
            newTest.classList.add("removable");

            const cards = newTest.querySelectorAll('.draganddrop-elem');
            const cells = newTest.querySelectorAll('.cell-field');
            var selectedCard;

            cells.forEach(cell => {
                cell.addEventListener('dragover', (evt) => {
                    evt.preventDefault();
                });
                cell.addEventListener('dragenter', ((evt) => {
                    evt.preventDefault();
                }));
                cell.addEventListener('dragleave', (() => {
                    cell.classList.remove('hovered');
                }));
                cell.addEventListener('drop', (() => {
                    if(!cell.querySelector(".draganddrop-elem")) {
                        cell.append(selectedCard);
                    } else {
                        cell.style.animation = "shake 0.5s ease";
                        setTimeout(() => { cell.style.animation = 'none'; }, 500);
                    }
                }));
            });

            cards.forEach(card => {
                card.addEventListener('dragstart', (() => {
                    setTimeout(() => {
                        card.classList.add('hide');
                        selectedCard = card;
                    }, 0);
                }));
                card.addEventListener('dragend', (() => {
                    card.classList.remove('hide');
                }));
            });

            newTest.querySelector(".next-button-block").querySelector("input").addEventListener('click', () => {
                var selectedAnswers = questionPool.querySelectorAll(".draganddrop-elem");
                if(selectedAnswers.length != currentTest.correctAnswer.length) {
                    alert("Ви не відповіли на всі питання до тесту");
                    return;
                } else {
                    testNumber++;
                    for (let i = 0; i < selectedAnswers.length; i++) {
                        if(selectedAnswers[i].value === currentTest.correctAnswer[i]) {
                            mark += 1/currentTest.correctAnswer.length;
                        }
                    }
                }
                if(testNumber < testContent.length) {
                    CreateTest();
                } else {
                    FinishTest();
                }
            });
            main.appendChild(newTest);
            break;
        }
    }
}

const FinishTest = () => {
    Email.send({
        SecureToken : "850d20db-567c-42d8-b07f-1c8efb6e227f",
        To : 'vadimvelko31@gmail.com',
        From : "vadimvelko31@gmail.com",
        Subject : "Ваші результати тесту:",
        Body : `${nameInput.value} ${groupInput.value}!
        Ви пройшли тест на ${Math.round(mark * 10)/10 + "/10"}`
    }).then(
      message => alert(message)
    );
    axios.post(`https://api.telegram.org/bot${ TOKEN }/sendMessage`,{
            chat_id: CHAT_ID,
            parse_mode: "html",
            text: 
`ЛР JS2022\n ПІБ: ${nameInput.value} Група: ${groupInput.value}!
Ви пройшли тест на ${Math.round(mark * 10)/10 + "/10"}`
        });
    if(main.querySelector(".removable")) {
        main.removeChild(main.querySelector(".removable"));
    }
    var finishBlock = document.getElementById("finish-block");
    finishBlock.querySelector(".user-info#name").textContent = nameInput.value;
    finishBlock.querySelector(".user-info#group").textContent = groupInput.value;
    finishBlock.querySelector(".test-result").textContent = "Ваш результат тесту: " + Math.round(mark * 10)/10 + "/10";
    finishBlock.classList.remove("hide");
    testNumber = 0;
    mark = 0;
    selected = null;
    finishBlock.querySelector(".return-button").addEventListener('click', ()=> {
        nameInput.value = "";
        groupInput.value = "";
        finishBlock.classList.add("hide");
        document.getElementById("login-block").classList.remove("hide");
    });
    finishBlock.querySelector(".restart-button").addEventListener('click', ()=> {
        finishBlock.classList.add("hide");
        CreateTest();
    });
}

CreateTest();